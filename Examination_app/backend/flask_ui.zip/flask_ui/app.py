from flask import Flask, render_template, request, redirect, url_for, flash
import requests

app = Flask(__name__)
app.secret_key = "exam_secret"  # for flash messages

FASTAPI_URL = "http://127.0.0.1:8001"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        data = {
            "username": request.form["username"],
            "password": request.form["password"]
        }
        response = requests.post(f"{FASTAPI_URL}/auth/login", json=data)
        if response.status_code == 200:
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid credentials!")
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    # Example: get questions from FastAPI
    response = requests.get(f"{FASTAPI_URL}/questions/")
    questions = response.json() if response.status_code == 200 else []
    return render_template("dashboard.html", questions=questions)

if __name__ == "__main__":
    app.run(port=5000, debug=True)
